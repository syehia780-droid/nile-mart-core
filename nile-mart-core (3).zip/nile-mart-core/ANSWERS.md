# ANSWERS

## Checkpoint 1

1. `new StandardPricingService()` is written in `ManualWiring` (the class that builds every object by hand). To switch
   to promotional pricing I edit `ManualWiring` only.
2. No. `ProductService` only knows the `PricingService` interface, so it does not care which implementation it gets
   (Dependency Inversion).
3. The class that wires everything (`main`) would own all the `new` calls: a long, order-dependent list that changes
   whenever any constructor changes. Spring's container takes that job (Inversion of Control).
4. A `HashMap` puts the key in a bucket chosen by `hashCode()` at the moment of `put`. If the sku changes afterwards,
   the `hashCode` changes, `get()` looks in another bucket and does not find the entry even though it is still inside.
   That is why `sku` is `final` in `Product`.

## Checkpoint 2

1. The scan registers `appConfig`, `inMemoryProductRepository`, `productService`, `standardPricingService`,
   `promotionalPricingService` (and, from later stages, the shipping, notification, cart and checkout beans), plus
   Spring's own internal beans. Not in the list: `Product`, `Customer`, `Order`, `OrderLine`, `Quote`, `CartView`
   (data created with `new`), and `Main` / `StoreConsole` (no stereotype annotation).
2. Without `@Primary`, Spring throws `NoUniqueBeanDefinitionException`: expected a single matching bean but found 2:
   `promotionalPricingService` and `standardPricingService`.
3. No. `@ComponentScan` only discovers classes and registers bean definitions (recipes). The objects are created
   afterwards, when the container instantiates its singletons.

## Checkpoint 3

1. `ShippingQuoteService` first parameter has no qualifier, so Spring finds two `ShippingCalculator` beans and
   `@Primary` on `ZoneShippingCalculator` wins. The second parameter uses `@Qualifier("freeShipping")`, which selects
   the bean named `freeShipping`. `@Primary` is a default set on the bean; `@Qualifier` is a choice made at the
   injection point.
2. A third calculator without any marker is just one more candidate; `@Primary` on `ZoneShippingCalculator` still
   wins, so nothing fails, and the new class is silently never injected there. An error only appears if two beans are
   both `@Primary`, or if the `@Primary` is removed.
3. `quote(Governorate.CAIRO, 5000.00)` returns `0.00`; `quote(Governorate.MATROUH, 999999.00)` returns `120.00`
   because the `REMOTE` zone is never free.
4. A new `PushNotificationSender extends AbstractNotificationSender` with `@Component` and `@Order(3)`. No existing
   file changes, because `CheckoutService` receives `List<NotificationSender>` (Open/Closed).

## Checkpoint 4

1. `getBean(ProductService.class) == getBean(ProductService.class)` prints `true` (singleton); the same line with
   `ShoppingCart` prints `false` (prototype).
2. It prints once. `@PostConstruct` runs when the singleton bean is created, once at startup, not on every `getBean`.
3. A singleton is built once, so it receives one cart for its whole life, shared by every customer. Someone has to ask
   the container for each new cart: `CartRegistry`, through `ObjectProvider<ShoppingCart>.getObject()`.
4. `lines.get(sku)` returns `null` for a product that is not in the cart, and `null + qty` throws a
   `NullPointerException` when Java unboxes the `Integer`. `getOrDefault(sku, 0)` gives `0` instead.
5. `LinkedHashMap` keeps the insertion order, so the lines of a cart appear in the order they were added. A `HashMap`
   gives no order guarantee.

## Checkpoint 6

1. The bean names contain `productController`, `cartController`, `checkoutController`, `orderController`,
   `globalExceptionHandler`, `cartRegistry`, and the three beans of `WebConfig` (`templateResolver`,
   `templateEngine`, `thymeleafViewResolver`). `StoreConsole` is not there: it has no stereotype, `Main` creates it
   with `new` and hands it the beans.
2. In `CartRegistry.open`: `cartProvider.getObject()`. The registry asks the container for a new prototype cart, once
   per customer.
3. Both front doors use the same `CartRegistry` singleton from the same container. If `StoreConsole` made its own
   `new CartRegistry(...)`, it would have its own empty map, and carts would no longer be shared (WEB-05 broken).
4. After a `POST`, returning a view leaves the browser's last request as the `POST`, so F5 sends the form again and
   creates another cart. With `redirect:/carts/N` the last request is a `GET`, and F5 only reloads the page.
5. `synchronized` on `placeOrder`. The loser enters after the winner finishes; the winner already emptied the cart, so
   the loser sees the error page with 400 "The cart is empty." (for two different carts competing for the same stock,
   it sees 409 "Only N available ...").
6. Spring no longer registers the class as a bean, so no handler is mapped to `/carts`, and the browser shows
   Tomcat's own 404 page.

## Principles

| Principle | Where |
|---|---|
| Encapsulation | `ShoppingCart` has private fields, exposes `lines()` as an unmodifiable view, has no quantity setter, and can be opened once; `Product` has private fields. |
| Abstraction, interfaces | `ProductService` and the checkout code only know `ProductRepository`, `PricingService`, `ShippingCalculator` and `NotificationSender`, never the classes behind them. |
| Polymorphism | `CheckoutService` loops over `List<NotificationSender>` and `GlobalExceptionHandler` calls `ex.status()`, with no `instanceof` and no if/else on a type. |
| Inheritance | `AbstractNotificationSender` holds the shared code with a `final send`, and `StoreException` is the parent of `NotFoundException` and `OutOfStockException`. |
| Composition over inheritance | `CheckoutService` has five collaborators and extends nothing. |
| SOLID | S: `TaxCalculator` only does VAT; O: a new sender or calculator is a new class with no edits; L: `ZoneShippingCalculator` and `FreeShippingCalculator` replace each other; I: `NotificationSender` has two methods; D: constructors take interfaces or beans, never `new` of a collaborator. |
| Generics | `Repository<T, ID>` and `Check.found(Optional<T>, Supplier<? extends StoreException>)`. |
| Collections | `ConcurrentHashMap` in `InMemoryProductRepository` and `CartRegistry`, `LinkedHashMap` in `ShoppingCart`, `EnumMap` in `ProductService.groupByCategory`, `EnumSet` in `Zone.governorates`, `CopyOnWriteArrayList` in `OrderRegistry` (each with a one-line reason in a comment). |
| Streams and lambdas | `ShoppingCart.subtotal`, `ProductService.groupByCategory`, `ProductService.search(Predicate)`, `OrderRegistry.revenue`. |
| Optional | `ProductRepository.findBySku`, `OrderRegistry.findByNumber`; never `.get()`, always `orElseThrow` or `Check.found`. |
| Exceptions | The `StoreException` family is unchecked; `InMemoryProductRepository.loadCatalog` catches the checked `IOException` and wraps it with its cause. |
| Immutability, records | `Customer`, `Order`, `OrderLine`, `Quote`, `CartView`, `LineView` (compact constructors validate and use `List.copyOf`). |
| Enums | `Zone`, `Governorate` and `Category` have fields, constructors and methods. |
| equals, hashCode, toString | `Product` uses `@EqualsAndHashCode.Include` on the sku only (proved with a `HashSet` in `ManualWiring`, Stage 1). |
| Numbers and BigDecimal | `Money` and `ShippingQuoteService` (`compareTo` against the threshold, never `equals` or `double`). |
| static, final, nested | `Money` and `Check` are final utility classes with a private constructor; constants are `static final`; fields are `final` unless they must change. |
| Default methods | `ProductRepository.findBySku` and `NotificationSender.supports`. |
| Concurrency | `CartRegistry` (`AtomicInteger`, `ConcurrentHashMap`), `OrderRegistry` (`AtomicInteger`, `CopyOnWriteArrayList`), `CheckoutService.placeOrder` and `ProductService.reduceStock` (`synchronized`). |
| I/O, try-with-resources | `InMemoryProductRepository.loadCatalog` (`BufferedReader`) and `Main` (the web server and the container). |
| Date and time | `OrderRegistry.nextNumber` uses `LocalDate.now(clock)` with `DateTimeFormatter.BASIC_ISO_DATE`. |
| Strings and formatting | `Money.format` (`DecimalFormat` with `Locale.US`) and `OrderRegistry.nextNumber` (`String.format("NM-%s-%05d", ...)`). |
