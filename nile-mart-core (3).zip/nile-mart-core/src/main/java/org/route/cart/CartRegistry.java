package org.route.cart;

import lombok.RequiredArgsConstructor;
import org.route.common.Check;
import org.route.common.NotFoundException;
import org.route.model.Customer;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Component;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * One registry for BOTH front doors (WEB-05). It is a singleton, but a cart is a prototype:
 * ObjectProvider asks the container for a NEW cart every time (the Stage 4 trap).
 */
@Component
@RequiredArgsConstructor
public class CartRegistry {

    private final ObjectProvider<ShoppingCart> cartProvider;

    // AtomicInteger + ConcurrentHashMap: console (main thread) and web (Tomcat threads) use this together
    private final AtomicInteger counter = new AtomicInteger();
    private final Map<Integer, ShoppingCart> carts = new ConcurrentHashMap<>();

    public ShoppingCart open(Customer customer) {
        ShoppingCart cart = cartProvider.getObject();   // a brand-new prototype cart
        cart.open(counter.incrementAndGet(), customer);
        carts.put(cart.getNumber(), cart);
        return cart;
    }

    public ShoppingCart get(int number) {
        return Check.found(find(number), () -> new NotFoundException("Cart " + number + " was not found."));
    }

    public List<CartView> views() {
        return carts.values().stream()
                .map(ShoppingCart::view)
                .sorted(Comparator.comparingInt(CartView::number))
                .toList();
    }

    private Optional<ShoppingCart> find(int number) {
        return Optional.ofNullable(carts.get(number));
    }
}
