package org.route.model;

import org.route.common.StoreException;

/** Immutable data. The compact constructor validates it (WEB-02). */
public record Customer(String fullName, String phone, String email) {

    public Customer {
        if (fullName == null || fullName.isBlank()) {
            throw new StoreException("The customer name is required.");
        }
        if (phone == null || !phone.matches("01[0125][0-9]{8}")) {
            throw new StoreException("The phone must have 11 digits and start with 010, 011, 012 or 015.");
        }
        // a blank email means "no email": store null
        email = (email == null || email.isBlank()) ? null : email.trim();
        if (email != null && !email.contains("@")) {
            throw new StoreException("The email must contain @.");
        }
        fullName = fullName.trim();
    }
}
