package org.route.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.time.Clock;

/** Describes the container: where to scan for beans and where the properties live. */
@Configuration
@ComponentScan("org.route")
@PropertySource("classpath:application.properties")
public class AppConfig {

    /** We cannot put @Component on a JDK class: that is exactly what @Bean is for. */
    @Bean
    public Clock clock() {
        return Clock.systemDefaultZone();
    }
}
