package org.route.checkout;

import org.route.common.Money;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/** Single responsibility: it only calculates VAT (GEN-03). */
@Component
public class TaxCalculator {

    private final BigDecimal vatRate;

    public TaxCalculator(@Value("${store.vat-rate}") BigDecimal vatRate) {
        this.vatRate = vatRate;
    }

    public BigDecimal vat(BigDecimal subtotal) {
        return Money.scale(subtotal.multiply(vatRate));
    }
}
