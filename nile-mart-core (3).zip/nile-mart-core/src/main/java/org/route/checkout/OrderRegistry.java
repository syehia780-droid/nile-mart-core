package org.route.checkout;

import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import org.route.common.Money;
import org.route.model.Order;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

@Component
@RequiredArgsConstructor
public class OrderRegistry {

    // the clock is injected: tests (and we) never call LocalDate.now() directly
    private final Clock clock;

    // AtomicInteger: two threads can ask for a number at the same moment
    private final AtomicInteger counter = new AtomicInteger();

    // CopyOnWriteArrayList: many reads (screens), few writes (orders)
    private final List<Order> orders = new CopyOnWriteArrayList<>();

    /** Format NM-YYYYMMDD-NNNNN (GEN-07). The counter never resets. */
    public String nextNumber() {
        return String.format("NM-%s-%05d",
                LocalDate.now(clock).format(DateTimeFormatter.BASIC_ISO_DATE),
                counter.incrementAndGet());
    }

    public void save(Order order) {
        orders.add(order);
    }

    public Optional<Order> findByNumber(String orderNumber) {
        return orders.stream().filter(o -> o.orderNumber().equals(orderNumber)).findFirst();
    }

    /** Newest first. */
    public List<Order> findAll() {
        List<Order> newestFirst = new ArrayList<>(orders);
        Collections.reverse(newestFirst);
        return List.copyOf(newestFirst);
    }

    public BigDecimal revenue() {
        return orders.stream().map(Order::total).reduce(Money.ZERO, BigDecimal::add);
    }

    @PreDestroy
    void endOfDay() {
        System.out.println("End of day: " + orders.size() + " orders, revenue "
                + Money.format(revenue()) + " EGP.");
    }
}
