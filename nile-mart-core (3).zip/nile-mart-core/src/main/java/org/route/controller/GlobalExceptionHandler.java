package org.route.controller;

import jakarta.servlet.http.HttpServletResponse;
import org.route.common.StoreException;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

/** One place for every StoreException. No if/else on the type: each exception knows its own status. */
@ControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(StoreException.class)
    public String handle(StoreException ex, HttpServletResponse response, Model model) {
        response.setStatus(ex.status());   // polymorphism: 400, 404 or 409 (WEB-04)
        model.addAttribute("status", ex.status());
        model.addAttribute("message", ex.getMessage());
        return "error";
    }
}
