package org.route.repository;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.route.common.Money;
import org.route.common.StoreException;
import org.route.model.Category;
import org.route.model.Product;
import org.springframework.stereotype.Repository;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

@Repository
public class InMemoryProductRepository implements ProductRepository {

    // ConcurrentHashMap: the web server uses many threads, a plain HashMap is not safe
    private final Map<String, Product> products = new ConcurrentHashMap<>();

    @Override
    public List<Product> findAll() {
        // a copy: nobody outside can change our internal map
        return List.copyOf(products.values());
    }

    @Override
    public Optional<Product> findById(String sku) {
        return Optional.ofNullable(products.get(sku));
    }

    @Override
    public Product save(Product product) {
        products.put(product.getSku(), product);
        return product;
    }

    /** Lifecycle callback: Spring calls it once, after the bean is built and its dependencies are set. */
    @PostConstruct
    void loadCatalog() {
        InputStream stream = getClass().getResourceAsStream("/products.csv");
        if (stream == null) {
            throw new StoreException("The catalog could not be loaded.");
        }
        // closing the BufferedReader also closes the streams below it
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
            reader.readLine();   // skip the header line
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isBlank()) {
                    save(parse(line));
                }
            }
        } catch (IOException e) {
            // checked IOException is caught right here and wrapped, with its cause
            throw new StoreException("The catalog could not be loaded.", e);
        }
        System.out.println("Catalog loaded: " + products.size() + " products");
    }

    private Product parse(String line) {
        String[] parts = line.split(",");
        return new Product(parts[0].trim(), parts[1].trim(), Category.valueOf(parts[2].trim()),
                Money.of(parts[3].trim()), Integer.parseInt(parts[4].trim()));
    }

    /** Lifecycle callback: runs when the container is closed. */
    @PreDestroy
    void close() {
        System.out.println("Catalog closed");
    }
}
