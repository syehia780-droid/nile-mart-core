package org.route.repository;

import java.util.List;
import java.util.Optional;

/** One generic repository contract: T = the thing stored, ID = the type of its key. */
public interface Repository<T, ID> {

    List<T> findAll();

    Optional<T> findById(ID id);

    T save(T entity);
}
