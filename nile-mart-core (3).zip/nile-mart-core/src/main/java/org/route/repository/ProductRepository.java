package org.route.repository;

import org.route.model.Product;

import java.util.Optional;

public interface ProductRepository extends Repository<Product, String> {

    /** Default method: every implementation gets it for free, no parent class needed. */
    default Optional<Product> findBySku(String sku) {
        return findById(sku);
    }
}
