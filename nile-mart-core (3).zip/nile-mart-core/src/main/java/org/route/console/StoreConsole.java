package org.route.console;

import org.route.cart.CartRegistry;
import org.route.cart.CartView;
import org.route.cart.ShoppingCart;
import org.route.checkout.CheckoutService;
import org.route.checkout.Quote;
import org.route.common.Money;
import org.route.common.StoreException;
import org.route.model.Customer;
import org.route.model.Governorate;
import org.route.model.Order;
import org.route.service.ProductService;

import java.util.Arrays;
import java.util.Scanner;

/** The console front door. A plain object, NOT a bean: Main creates it. */
public class StoreConsole {

    // the SAME CartRegistry bean as the web controllers use: a cart made here shows up in the browser (WEB-05)
    private final CartRegistry cartRegistry;
    private final ProductService productService;
    private final CheckoutService checkoutService;
    private final Scanner in = new Scanner(System.in);

    public StoreConsole(CartRegistry cartRegistry, ProductService productService, CheckoutService checkoutService) {
        this.cartRegistry = cartRegistry;
        this.productService = productService;
        this.checkoutService = checkoutService;
    }

    public void run() {
        while (true) {
            printMenu();
            if (!in.hasNextLine()) {
                return;   // no more input
            }
            String choice = in.nextLine().trim();
            if (choice.equals("0")) {
                return;
            }
            try {
                handle(choice);
            } catch (StoreException e) {
                // a mistake must never end the program
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private void printMenu() {
        System.out.println("""

                ========== NILEMART ==========
                1. Show products
                2. Create a cart
                3. Add a product to a cart
                4. Show a cart
                5. Check out a cart
                0. Exit""");
        System.out.print("> ");
    }

    private void handle(String choice) {
        switch (choice) {
            case "1" -> showProducts();
            case "2" -> createCart();
            case "3" -> addToCart();
            case "4" -> showCart();
            case "5" -> checkout();
            default -> System.out.println("Please choose a number from the menu.");
        }
    }

    private void showProducts() {
        productService.groupByCategory().forEach((category, products) -> {
            System.out.println(category.getLabel());
            products.forEach(p -> System.out.printf("  %-12s %-28s %12s EGP  %s%n", p.getSku(), p.getName(),
                    Money.format(p.getPrice()),
                    p.getStockQuantity() == 0 ? "Out of stock" : p.getStockQuantity() + " in stock"));
        });
    }

    private void createCart() {
        String name = ask("Full name: ");
        String phone = ask("Phone: ");
        String email = ask("Email (optional): ");
        Customer customer = new Customer(name, phone, email);
        ShoppingCart cart = cartRegistry.open(customer);
        System.out.println("Cart " + cart.getNumber() + " created for " + customer.fullName() + ".");
    }

    private void addToCart() {
        ShoppingCart cart = findCart();
        String sku = ask("Product SKU: ");
        int qty = askNumber("Quantity: ");
        cart.addItem(sku, qty);
        System.out.println("Added " + qty + " x " + productService.findBySku(sku).getName()
                + " to cart " + cart.getNumber() + ".");
    }

    private void showCart() {
        printCart(findCart().view());
    }

    private void checkout() {
        ShoppingCart cart = findCart();
        System.out.println("Governorates: " + Arrays.stream(Governorate.values()).map(Enum::name).toList());
        Governorate governorate = parseGovernorate(ask("Governorate: "));
        Quote quote = checkoutService.quote(cart, governorate);
        System.out.println("Subtotal " + Money.format(quote.subtotal()) + " | VAT " + Money.format(quote.vat())
                + " | Shipping " + Money.format(quote.shippingFee()) + " | Total " + Money.format(quote.total()));
        if (ask("Place the order? (y/n): ").equalsIgnoreCase("y")) {
            Order order = checkoutService.placeOrder(cart, governorate);
            System.out.println("Order " + order.orderNumber() + " placed.");
        }
    }

    private void printCart(CartView view) {
        System.out.println("Cart " + view.number() + " - " + view.customer().fullName());
        if (view.empty()) {
            System.out.println("  (empty)");
            return;
        }
        view.lines().forEach(l -> System.out.printf("  %-28s x%-3d %12s EGP%n", l.name(), l.quantity(),
                Money.format(l.linePrice())));
        System.out.println("  Subtotal: " + Money.format(view.subtotal()) + " EGP");
    }

    private ShoppingCart findCart() {
        int number = askNumber("Cart number: ");
        return cartRegistry.get(number);
    }

    private Governorate parseGovernorate(String text) {
        try {
            return Governorate.valueOf(text.trim().toUpperCase().replace(' ', '_'));
        } catch (IllegalArgumentException e) {
            throw new StoreException("Governorate " + text + " is not known.", e);
        }
    }

    private String ask(String prompt) {
        System.out.print(prompt);
        return in.hasNextLine() ? in.nextLine().trim() : "";
    }

    private int askNumber(String prompt) {
        String text = ask(prompt);
        try {
            return Integer.parseInt(text);
        } catch (NumberFormatException e) {
            throw new StoreException("Please enter a whole number.", e);
        }
    }
}
