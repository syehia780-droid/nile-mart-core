package org.route;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @SpringBootApplication = @Configuration + @ComponentScan("org.route") + @EnableAutoConfiguration.
 * Boot starts Tomcat, enables Spring MVC and configures Thymeleaf for us.
 */
@SpringBootApplication
public class NileMartApplication {

    public static void main(String[] args) {
        SpringApplication.run(NileMartApplication.class, args);
    }
}
