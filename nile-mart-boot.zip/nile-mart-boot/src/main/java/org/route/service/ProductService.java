package org.route.service;

import lombok.RequiredArgsConstructor;
import org.route.common.Check;
import org.route.common.NotFoundException;
import org.route.common.OutOfStockException;
import org.route.model.Category;
import org.route.model.Product;
import org.route.pricing.PricingService;
import org.route.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProductService {

    // interfaces only: this class never knows which implementation it receives
    private final ProductRepository repository;
    private final PricingService pricingService;

    /** Sorted by category (enum order), then by name. */
    public List<Product> findAll() {
        return repository.findAll().stream()
                .sorted(Comparator.comparing(Product::getCategory)
                        .thenComparing(Product::getName))
                .toList();
    }

    public Product findBySku(String sku) {
        return Check.found(repository.findBySku(sku),
                () -> new NotFoundException("Product " + sku + " was not found."));
    }

    public BigDecimal getPrice(String sku, int qty) {
        return pricingService.getPrice(findBySku(sku), qty);
    }

    // check-then-change must be one step: two threads must not both pass the check
    public synchronized void reduceStock(String sku, int qty) {
        Product product = findBySku(sku);
        if (product.getStockQuantity() == 0) {
            throw new OutOfStockException(product.getName() + " is out of stock.");
        }
        if (qty > product.getStockQuantity()) {
            throw new OutOfStockException(
                    "Only " + product.getStockQuantity() + " available for " + product.getName() + ".");
        }
        product.setStockQuantity(product.getStockQuantity() - qty);
    }

    public List<Product> search(Predicate<Product> filter) {
        return findAll().stream().filter(filter).toList();
    }

    /** EnumMap: the categories come out in enum order. */
    public Map<Category, List<Product>> groupByCategory() {
        return findAll().stream()
                .collect(Collectors.groupingBy(
                        Product::getCategory,
                        () -> new EnumMap<>(Category.class),
                        Collectors.toList()));
    }
}
