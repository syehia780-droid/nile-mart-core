package org.route.notification;

import org.route.model.Customer;

/** Small interface: two methods at most (Interface Segregation). */
public interface NotificationSender {

    void send(Customer customer, String message);

    /** Default method: by default a sender can reach every customer. */
    default boolean supports(Customer customer) {
        return true;
    }
}
