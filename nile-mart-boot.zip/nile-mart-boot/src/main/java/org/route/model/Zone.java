package org.route.model;

import org.route.common.Money;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.EnumSet;
import java.util.Set;
import java.util.stream.Collectors;

public enum Zone {
    GREATER_CAIRO("50", true),
    ALEX_DELTA("65", true),
    CANAL("70", true),
    UPPER_EGYPT("85", true),
    REMOTE("120", false);

    private final BigDecimal fee;
    private final boolean freeShippingEligible;

    Zone(String fee, boolean freeShippingEligible) {
        this.fee = Money.of(fee);
        this.freeShippingEligible = freeShippingEligible;
    }

    public BigDecimal getFee() {
        return fee;
    }

    public boolean isFreeShippingEligible() {
        return freeShippingEligible;
    }

    /** All governorates of this zone. EnumSet: fast, ordered, made for enum values. */
    public Set<Governorate> governorates() {
        return Arrays.stream(Governorate.values())
                .filter(g -> g.getZone() == this)
                .collect(Collectors.toCollection(() -> EnumSet.noneOf(Governorate.class)));
    }
}
