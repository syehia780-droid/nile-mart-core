package org.route.shipping;

import org.route.model.Governorate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;

@Service
public class ShippingQuoteService {

    private final ShippingCalculator standardCalculator;
    private final ShippingCalculator freeCalculator;
    private final BigDecimal freeShippingThreshold;

    // first parameter: no qualifier, so the @Primary bean is used.
    // second parameter: @Qualifier picks one bean by its name.
    public ShippingQuoteService(ShippingCalculator standardCalculator,
                                @Qualifier("freeShipping") ShippingCalculator freeCalculator,
                                @Value("${store.free-shipping-threshold}") BigDecimal freeShippingThreshold) {
        this.standardCalculator = standardCalculator;
        this.freeCalculator = freeCalculator;
        this.freeShippingThreshold = freeShippingThreshold;
    }

    /** Free when subtotal >= threshold and the zone is eligible (REMOTE never is). */
    public BigDecimal quote(Governorate governorate, BigDecimal subtotal) {
        // compareTo, never equals: 5000.0 and 5000.00 are "not equal" for BigDecimal.equals
        boolean reachedThreshold = subtotal.compareTo(freeShippingThreshold) >= 0;
        if (reachedThreshold && governorate.getZone().isFreeShippingEligible()) {
            return freeCalculator.calculate(governorate);
        }
        return standardCalculator.calculate(governorate);
    }
}
