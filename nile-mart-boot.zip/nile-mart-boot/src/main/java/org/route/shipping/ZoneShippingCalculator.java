package org.route.shipping;

import org.route.model.Governorate;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/** The default calculator (@Primary): the fee of the governorate's zone. */
@Component
@Primary
public class ZoneShippingCalculator implements ShippingCalculator {

    @Override
    public BigDecimal calculate(Governorate governorate) {
        return governorate.getZone().getFee();
    }
}
