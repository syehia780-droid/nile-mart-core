package org.route.shipping;

import org.route.common.Money;
import org.route.model.Governorate;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/** Always free. Chosen by name with @Qualifier("freeShipping"). */
@Component("freeShipping")
public class FreeShippingCalculator implements ShippingCalculator {

    @Override
    public BigDecimal calculate(Governorate governorate) {
        return Money.ZERO;
    }
}
