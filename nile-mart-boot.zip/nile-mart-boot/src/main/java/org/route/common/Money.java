package org.route.common;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

/** Money helpers: BigDecimal, always 2 decimals, HALF_UP. */
public final class Money {

    // SCALE and ROUNDING must be declared BEFORE ZERO: ZERO calls scale() while the class loads
    private static final int SCALE = 2;
    private static final RoundingMode ROUNDING = RoundingMode.HALF_UP;

    public static final BigDecimal ZERO = scale(BigDecimal.ZERO);

    private Money() {
    }

    public static BigDecimal scale(BigDecimal value) {
        return value.setScale(SCALE, ROUNDING);
    }

    public static BigDecimal of(String text) {
        return scale(new BigDecimal(text));
    }

    public static String format(BigDecimal value) {
        // a new DecimalFormat on every call: DecimalFormat is not thread-safe
        DecimalFormat df = new DecimalFormat("#,##0.00", DecimalFormatSymbols.getInstance(Locale.US));
        return df.format(scale(value));
    }
}
