package org.route.common;

/** Base of every business-rule failure. Unchecked, and it knows its own HTTP status. */
public class StoreException extends RuntimeException {

    public StoreException(String message) {
        super(message);
    }

    public StoreException(String message, Throwable cause) {
        super(message, cause);
    }

    /** HTTP status used by the web layer. Default: 400 Bad Request. */
    public int status() {
        return 400;
    }
}
