package org.route.checkout;

import lombok.RequiredArgsConstructor;
import org.route.cart.LineView;
import org.route.cart.ShoppingCart;
import org.route.common.Money;
import org.route.common.OutOfStockException;
import org.route.common.StoreException;
import org.route.model.Governorate;
import org.route.model.Order;
import org.route.model.OrderLine;
import org.route.model.Product;
import org.route.notification.NotificationSender;
import org.route.repository.OrderRepository;
import org.route.service.ProductService;
import org.route.shipping.ShippingQuoteService;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

/** Composition over inheritance: five collaborators, extends nothing. */
@Service
@RequiredArgsConstructor
public class CheckoutService {

    private final ProductService productService;
    private final ShippingQuoteService shippingQuoteService;
    private final TaxCalculator taxCalculator;
    private final OrderRepository orderRepository;
    // Spring injects ALL NotificationSender beans, sorted by @Order. No instanceof, no if/else on type.
    private final List<NotificationSender> notificationSenders;

    /** Calculates the totals and changes nothing. */
    public Quote quote(ShoppingCart cart, Governorate governorate) {
        if (cart.isEmpty()) {
            throw new StoreException("The cart is empty.");
        }
        BigDecimal subtotal = cart.subtotal();
        BigDecimal vat = taxCalculator.vat(subtotal);
        BigDecimal shipping = shippingQuoteService.quote(governorate, subtotal);
        BigDecimal total = Money.scale(subtotal.add(vat).add(shipping));
        return new Quote(subtotal, vat, shipping, total);
    }

    // synchronized: "check stock, then reduce it" must be one step, or two customers could buy the same stock
    public synchronized Order placeOrder(ShoppingCart cart, Governorate governorate) {
        // 1) reject an empty cart
        if (cart.isEmpty()) {
            throw new StoreException("The cart is empty.");
        }
        // a snapshot of the lines: later steps never see a half-changed cart
        List<LineView> lines = cart.view().lines();

        // 2) re-check the stock of ALL lines, change nothing yet
        lines.forEach(line -> {
            Product product = productService.findBySku(line.sku());
            if (product.getStockQuantity() == 0) {
                throw new OutOfStockException(product.getName() + " is out of stock.");
            }
            if (line.quantity() > product.getStockQuantity()) {
                throw new OutOfStockException(
                        "Only " + product.getStockQuantity() + " available for " + product.getName() + ".");
            }
        });

        // 3) totals
        Quote quote = quote(cart, governorate);

        // 4) reduce the stock of all lines (all or none: the check above already passed)
        lines.forEach(line -> productService.reduceStock(line.sku(), line.quantity()));

        // 5) save the order and take its number
        List<OrderLine> orderLines = lines.stream()
                .map(l -> new OrderLine(l.sku(), l.name(), l.quantity(), l.linePrice()))
                .toList();
        Order order = new Order(orderRepository.nextNumber(), cart.getCustomer(), governorate, orderLines,
                quote.subtotal(), quote.vat(), quote.shippingFee(), quote.total());
        orderRepository.save(order);

        // 6) notify through every sender
        String message = "Order " + order.orderNumber() + " confirmed. Total "
                + Money.format(order.total()) + " EGP";
        // (each sender decides by itself, through supports(), whether it can reach this customer)
        notificationSenders.forEach(sender -> sender.send(order.customer(), message));

        // 7) clear the cart and return the order
        cart.clear();
        return order;
    }
}
