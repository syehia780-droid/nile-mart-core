package org.route.checkout;

import java.math.BigDecimal;

/** The price breakdown of a cart for one governorate. Changes nothing. */
public record Quote(BigDecimal subtotal, BigDecimal vat, BigDecimal shippingFee, BigDecimal total) {
}
