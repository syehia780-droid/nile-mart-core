package org.route.pricing;

import org.route.model.Product;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;

/** Every line gets a percentage off. The percentage is passed in, never hard-coded. */
@Component
public class PromotionalPricingService implements PricingService {

    private static final BigDecimal HUNDRED = BigDecimal.valueOf(100);

    private final BigDecimal discountPercent;

    public PromotionalPricingService(@Value("${store.discount-amount}") BigDecimal discountPercent) {
        this.discountPercent = discountPercent;
    }

    @Override
    public BigDecimal getPrice(Product product, int qty) {
        BigDecimal lineTotal = product.getPrice().multiply(BigDecimal.valueOf(qty));
        BigDecimal remainingPercent = HUNDRED.subtract(discountPercent);
        // round once, at the end
        return lineTotal.multiply(remainingPercent).divide(HUNDRED, 2, RoundingMode.HALF_UP);
    }
}
