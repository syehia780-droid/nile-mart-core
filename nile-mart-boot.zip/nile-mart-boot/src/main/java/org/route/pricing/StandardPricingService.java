package org.route.pricing;

import org.route.common.Money;
import org.route.model.Product;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/** @Primary: the default PricingService. Switching pricing = moving this one annotation. */
@Component
@Primary
public class StandardPricingService implements PricingService {

    @Override
    public BigDecimal getPrice(Product product, int qty) {
        return Money.scale(product.getPrice().multiply(BigDecimal.valueOf(qty)));
    }
}
