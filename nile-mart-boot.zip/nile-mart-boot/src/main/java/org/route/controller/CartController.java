package org.route.controller;

import lombok.RequiredArgsConstructor;
import org.route.repository.CartRepository;
import org.route.cart.ShoppingCart;
import org.route.common.StoreException;
import org.route.controller.form.AddItemForm;
import org.route.controller.form.NewCartForm;
import org.route.model.Customer;
import org.route.model.Product;
import org.route.service.ProductService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

/** Singleton shared by every visitor: no state here, carts live in CartRepository. */
@Controller
@RequiredArgsConstructor
public class CartController {

    private final CartRepository cartRepository;
    private final ProductService productService;

    @GetMapping("/carts")
    public String list(Model model) {
        model.addAttribute("carts", cartRepository.findAllViews());
        return "carts/list";
    }

    @GetMapping("/carts/new")
    public String newForm(Model model) {
        model.addAttribute("form", new NewCartForm());
        return "carts/new";
    }

    @PostMapping("/carts")
    public String create(@ModelAttribute("form") NewCartForm form, RedirectAttributes redirect) {
        // the Customer record validates itself; a blank email becomes null there
        Customer customer = new Customer(form.getFullName(), form.getPhone(), form.getEmail());
        ShoppingCart cart = cartRepository.open(customer);
        redirect.addFlashAttribute("message", "Cart " + cart.getNumber() + " created for " + customer.fullName() + ".");
        return "redirect:/carts/" + cart.getNumber();   // Post/Redirect/Get
    }

    @GetMapping("/carts/{number}")
    public String view(@PathVariable int number, Model model) {
        model.addAttribute("cart", cartRepository.get(number).view());
        model.addAttribute("products", productService.search(p -> p.getStockQuantity() > 0));
        return "carts/view";
    }

    @PostMapping("/carts/items")
    public String addItem(@ModelAttribute AddItemForm form, RedirectAttributes redirect) {
        if (form.getCartNumber() == null) {
            throw new StoreException("Choose a cart.");
        }
        if (form.getSku() == null || form.getSku().isBlank()) {
            throw new StoreException("Choose a product.");
        }
        if (form.getQuantity() == null) {
            throw new StoreException("Enter a quantity.");
        }
        cartRepository.get(form.getCartNumber()).addItem(form.getSku(), form.getQuantity());
        Product product = productService.findBySku(form.getSku());
        redirect.addFlashAttribute("message", "Added " + form.getQuantity() + " x " + product.getName()
                + " to cart " + form.getCartNumber() + ".");
        return "redirect:/carts/" + form.getCartNumber();
    }
}
