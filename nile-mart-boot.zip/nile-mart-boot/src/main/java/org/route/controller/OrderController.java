package org.route.controller;

import lombok.RequiredArgsConstructor;
import org.route.repository.OrderRepository;
import org.route.common.Check;
import org.route.common.NotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
@RequiredArgsConstructor
public class OrderController {

    private final OrderRepository orderRepository;

    @GetMapping("/orders")
    public String list(Model model) {
        model.addAttribute("orders", orderRepository.findAll());
        model.addAttribute("revenue", orderRepository.totalRevenue());
        return "orders/list";
    }

    @GetMapping("/orders/{orderNumber}")
    public String view(@PathVariable String orderNumber, Model model) {
        model.addAttribute("order", Check.found(orderRepository.findByNumber(orderNumber),
                () -> new NotFoundException("Order " + orderNumber + " was not found.")));
        return "orders/confirmation";
    }
}
