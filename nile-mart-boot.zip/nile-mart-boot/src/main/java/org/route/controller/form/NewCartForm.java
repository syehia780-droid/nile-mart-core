package org.route.controller.form;

import lombok.Data;
import lombok.NoArgsConstructor;

/** The field names match the name="..." of the inputs in carts/new.html. */
@Data
@NoArgsConstructor
public class NewCartForm {
    private String fullName;
    private String phone;
    private String email;
}
