package org.route.controller.form;

import lombok.Data;
import lombok.NoArgsConstructor;

/** Integer (not int): an empty field must become null, so we can say "Enter a quantity." */
@Data
@NoArgsConstructor
public class AddItemForm {
    private Integer cartNumber;
    private String sku;
    private Integer quantity;
}
