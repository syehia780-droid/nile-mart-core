package org.route.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.Clock;

@Configuration
public class AppConfig {

    /** We cannot put @Component on a JDK class, so we declare it as a bean here. */
    @Bean
    public Clock clock() {
        return Clock.systemDefaultZone();
    }
}
