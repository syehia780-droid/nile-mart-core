package org.route.cart;

import org.route.model.Customer;

import java.math.BigDecimal;
import java.util.List;

/** What a screen sees of a cart: an immutable snapshot, never the live cart. */
public record CartView(int number, Customer customer, List<LineView> lines,
                       int itemCount, BigDecimal subtotal, boolean empty) {

    public CartView {
        lines = List.copyOf(lines);
    }
}
