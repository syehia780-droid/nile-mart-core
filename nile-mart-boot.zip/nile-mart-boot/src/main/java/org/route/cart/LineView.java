package org.route.cart;

import java.math.BigDecimal;

/** What a screen sees of one cart line: an immutable snapshot. */
public record LineView(String sku, String name, int quantity, BigDecimal linePrice) {
}
