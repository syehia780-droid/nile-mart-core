package org.route.cart;

import lombok.Getter;
import org.route.common.Money;
import org.route.common.OutOfStockException;
import org.route.common.StoreException;
import org.route.model.Customer;
import org.route.model.Product;
import org.route.service.ProductService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/** prototype scope: every getBean() / ObjectProvider.getObject() returns a NEW cart. */
@Component
@Scope("prototype")
public class ShoppingCart {

    private final ProductService productService;
    private final int maxQuantity;

    // LinkedHashMap: lines keep the order in which they were added
    private final Map<String, Integer> lines = new LinkedHashMap<>();

    @Getter
    private int number;
    @Getter
    private Customer customer;

    public ShoppingCart(ProductService productService,
                        @Value("${store.max-quantity-per-product}") int maxQuantity) {
        this.productService = productService;
        this.maxQuantity = maxQuantity;
    }

    /** A cart can be opened only once. */
    public synchronized void open(int number, Customer customer) {
        if (this.customer != null) {
            throw new IllegalStateException("Cart " + this.number + " is already open.");
        }
        this.number = number;
        this.customer = Objects.requireNonNull(customer);
    }

    /** The checks run in a fixed order. */
    public synchronized void addItem(String sku, int qty) {
        if (qty < 1) {
            throw new StoreException("The quantity must be at least 1.");
        }
        Product product = productService.findBySku(sku);
        if (product.getStockQuantity() == 0) {
            throw new OutOfStockException(product.getName() + " is out of stock.");
        }
        // getOrDefault: get(sku) would return null for a new product, and null + qty throws NPE on unboxing
        int newQty = lines.getOrDefault(sku, 0) + qty;
        if (newQty > maxQuantity) {
            throw new StoreException("You can add at most " + maxQuantity + " of " + product.getName() + ".");
        }
        if (newQty > product.getStockQuantity()) {
            throw new OutOfStockException(
                    "Only " + product.getStockQuantity() + " available for " + product.getName() + ".");
        }
        lines.put(sku, newQty);
    }

    /** Every line price comes from the pricing service. */
    public synchronized BigDecimal subtotal() {
        return lines.entrySet().stream()
                .map(e -> productService.getPrice(e.getKey(), e.getValue()))
                .reduce(Money.ZERO, BigDecimal::add);
    }

    public synchronized boolean isEmpty() {
        return lines.isEmpty();
    }

    public synchronized void clear() {
        lines.clear();
    }

    /** Read-only view: callers cannot change the cart through it. */
    public Map<String, Integer> lines() {
        return Collections.unmodifiableMap(lines);
    }

    public synchronized CartView view() {
        var lineViews = lines.entrySet().stream()
                .map(e -> {
                    Product p = productService.findBySku(e.getKey());
                    return new LineView(p.getSku(), p.getName(), e.getValue(),
                            productService.getPrice(e.getKey(), e.getValue()));
                })
                .toList();
        int itemCount = lines.values().stream().mapToInt(Integer::intValue).sum();
        return new CartView(number, customer, lineViews, itemCount, subtotal(), lines.isEmpty());
    }
}
