package org.route.repository;

import jakarta.annotation.PreDestroy;
import lombok.RequiredArgsConstructor;
import org.route.common.Money;
import org.route.model.Order;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.Clock;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;

/** Plays the role of the "orders" table. */
@Repository
@RequiredArgsConstructor
public class OrderRepository {

    // the clock is injected: we never call LocalDate.now() directly
    private final Clock clock;

    // AtomicInteger: like a database sequence. Two threads can ask for a number at the same moment
    private final AtomicInteger sequence = new AtomicInteger();

    // CopyOnWriteArrayList: many reads (pages), few writes (orders)
    private final List<Order> table = new CopyOnWriteArrayList<>();

    /** Format NM-YYYYMMDD-NNNNN. The sequence never resets. */
    public String nextNumber() {
        return String.format("NM-%s-%05d",
                LocalDate.now(clock).format(DateTimeFormatter.BASIC_ISO_DATE),
                sequence.incrementAndGet());
    }

    public Order save(Order order) {
        table.add(order);
        return order;
    }

    public Optional<Order> findByNumber(String orderNumber) {
        return table.stream().filter(o -> o.orderNumber().equals(orderNumber)).findFirst();
    }

    /** Newest first. */
    public List<Order> findAll() {
        List<Order> newestFirst = new ArrayList<>(table);
        Collections.reverse(newestFirst);
        return List.copyOf(newestFirst);
    }

    public BigDecimal totalRevenue() {
        return table.stream().map(Order::total).reduce(Money.ZERO, BigDecimal::add);
    }

    @PreDestroy
    void endOfDay() {
        System.out.println("End of day: " + table.size() + " orders, revenue "
                + Money.format(totalRevenue()) + " EGP.");
    }
}
