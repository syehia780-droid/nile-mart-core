package org.route.repository;

import lombok.RequiredArgsConstructor;
import org.route.cart.CartView;
import org.route.cart.ShoppingCart;
import org.route.common.Check;
import org.route.common.NotFoundException;
import org.route.model.Customer;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Repository;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Plays the role of the "carts" table. This class is a singleton, but a cart is a prototype:
 * ObjectProvider asks the container for a NEW cart every time, so each customer gets their own.
 */
@Repository
@RequiredArgsConstructor
public class CartRepository {

    private final ObjectProvider<ShoppingCart> cartProvider;

    private final AtomicInteger sequence = new AtomicInteger();
    private final Map<Integer, ShoppingCart> table = new ConcurrentHashMap<>();

    public ShoppingCart open(Customer customer) {
        ShoppingCart cart = cartProvider.getObject();   // a brand-new prototype cart
        cart.open(sequence.incrementAndGet(), customer);
        table.put(cart.getNumber(), cart);
        return cart;
    }

    public ShoppingCart get(int number) {
        return Check.found(find(number), () -> new NotFoundException("Cart " + number + " was not found."));
    }

    public List<CartView> findAllViews() {
        return table.values().stream()
                .map(ShoppingCart::view)
                .sorted(Comparator.comparingInt(CartView::number))
                .toList();
    }

    private Optional<ShoppingCart> find(int number) {
        return Optional.ofNullable(table.get(number));
    }
}
