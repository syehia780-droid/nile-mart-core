package org.route.repository;

import jakarta.annotation.PostConstruct;
import org.route.common.Money;
import org.route.model.Category;
import org.route.model.Product;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

/** Plays the role of the "products" table. A Map is the table, the Product is a row, the sku is the primary key. */
@Repository
public class ProductRepository {

    // ConcurrentHashMap: many web requests (threads) read and write at the same time
    private final Map<String, Product> table = new ConcurrentHashMap<>();

    public List<Product> findAll() {
        // a copy: nobody outside can change our table
        return List.copyOf(table.values());
    }

    public Optional<Product> findBySku(String sku) {
        return Optional.ofNullable(table.get(sku));
    }

    public Product save(Product product) {
        table.put(product.getSku(), product);
        return product;
    }

    /** Runs once, right after Spring builds this bean: fills the "table" with the starting rows. */
    @PostConstruct
    void loadSeedData() {
        save(new Product("PH-X5-128", "Smartphone X5 128GB", Category.ELECTRONICS, Money.of("16000.00"), 12));
        save(new Product("ACC-CHG-20W", "Fast Charger 20W", Category.ELECTRONICS, Money.of("650.00"), 40));
        save(new Product("ACC-BUDS-6", "Wireless Earbuds", Category.ELECTRONICS, Money.of("1100.00"), 8));
        save(new Product("FSH-GAL-001", "Cotton Galabeya", Category.FASHION, Money.of("900.00"), 25));
        save(new Product("HOM-PAN-28", "Non-stick Frying Pan 28cm", Category.HOME_KITCHEN, Money.of("1200.00"), 3));
        save(new Product("HOM-SPC-RCK", "Wooden Spice Rack", Category.HOME_KITCHEN, Money.of("750.00"), 10));
        save(new Product("BTY-SUN-50", "Sun Cream SPF50", Category.BEAUTY, Money.of("350.00"), 0));
        save(new Product("BK-CAI-TRI", "The Cairo Trilogy", Category.BOOKS, Money.of("450.00"), 15));
    }
}
