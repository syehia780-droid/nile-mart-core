# NileMart (Spring Boot)

A small online shop built with **Spring Boot 3, Spring MVC and Thymeleaf**. The server returns **HTML pages**
(back end and front end in one project). There is no database: the repositories are plain Java classes that keep
the data in memory, the way a database table would.

## Run it

```bash
mvn spring-boot:run
```

or run the `NileMartApplication` class from the IDE. Then open <http://localhost:8080/>.
Requirements: JDK 17 or newer, Maven 3.9+.

## What it does

Customers open carts, add products from the catalog, and check out. The shop adds 14% VAT and a shipping fee that
depends on the governorate (free from 5,000 EGP, except the remote zone), re-checks the stock, saves an order
numbered `NM-YYYYMMDD-NNNNN`, and prints an SMS and an email confirmation in the console.

## Layers

```
Browser ──► Controller ──► Service ──► Repository ──► (in-memory "tables")
               │                          ▲
               └── Model ◄────────────────┘
               └── Thymeleaf view (HTML)
```

| Layer | Package | Responsibility |
|---|---|---|
| Model | `model` | data and its rules: `Product`, `Customer`, `Order`, `Zone`, `Governorate` |
| Repository | `repository` | storing and finding data: `ProductRepository`, `CartRepository`, `OrderRepository` |
| Service | `service`, `pricing`, `shipping`, `checkout`, `notification`, `cart` | business logic |
| Controller | `controller` | receives the request, calls services, chooses the page |
| View | `resources/templates` | Thymeleaf HTML pages |

## Not used on purpose

Tests, database, and security.

## Troubleshooting

* `TypeTag :: UNKNOWN` while compiling: the JDK is newer than Lombok. Use JDK 21, or raise `lombok.version` in `pom.xml`.
* In IntelliJ, enable **Settings → Build → Compiler → Annotation Processors → Enable annotation processing**.
* `Port 8080 was already in use`: stop the other program, or set `server.port=8081` in `application.properties`.
